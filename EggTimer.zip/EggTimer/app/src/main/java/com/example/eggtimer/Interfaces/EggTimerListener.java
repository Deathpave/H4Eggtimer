package com.example.eggtimer.Interfaces;

public interface EggTimerListener {
    public void onCountDown(long timeLeft);
    public void onEggTimerStopped();
}
