package com.example.eggtimer;


import com.example.eggtimer.Interfaces.EggTimerListener;

public class EggTimer extends Thread implements EggTimerListener {

    long cookingTime;
    public EggTimer(long cookingTime)
    {
        this.cookingTime = cookingTime;
    }
    public void run()
    {
        if (cookingTime <= 0) {

        } else {
                cookingTime = cookingTime-1000;
            try {
                Thread.currentThread().wait(1000);
                cookingTime = cookingTime - 1000;
                onCountDown(cookingTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onCountDown(long timeLeft) {

    }

    @Override
    public void onEggTimerStopped() {

    }
}
