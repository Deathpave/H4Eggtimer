package com.example.eggtimer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.text.format.Time;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.eggtimer.Interfaces.EggTimerListener;
import com.example.eggtimer.Managers.EggManager;

import java.util.Timer;

public class MainActivity extends AppCompatActivity implements EggTimerListener {

    EggManager manager = new EggManager();
    long cookingTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        manager.setRuning(false);
        setContentView(R.layout.activity_main);
    }

    public void onTimerButtonClicked(final View view)
    {
        switch (view.getId())
        {
            case R.id.softBtn:
                ((EditText)findViewById(R.id.textNumber)).setText("05:00");
                cookingTime = 300000;
                manager.setCookingTime(300000);
                break;
            case R.id.mediumBtn:
                ((EditText)findViewById(R.id.textNumber)).setText("07:00");
                cookingTime = 420000;
                manager.setCookingTime(420000);
                break;
            case R.id.hardBtn:
                ((EditText)findViewById(R.id.textNumber)).setText("10:00");
                cookingTime = 600000;
                manager.setCookingTime(600000);
                break;
            default:
                throw new RuntimeException("Unknown button ID");
        }
        findViewById(R.id.startBtn).setEnabled(true);
    }

    public void onStartButtonClicked(final View view)
    {
        if (manager.getRunning())
        {
            onStop(view);
        }
        else {
            findViewById(R.id.softBtn).setEnabled(false);
            findViewById(R.id.mediumBtn).setEnabled(false);
            findViewById(R.id.hardBtn).setEnabled(false);
            // TODO
            manager.setRuning(true);
            EggTimer timer = new EggTimer(cookingTime);
            timer.start();
            // TODO
            ((Button)findViewById(R.id.startBtn)).setText("Stop");
            Handler handler = new Handler();
            handler.post(new Runnable() {
                @Override
                public void run() {
                            if (manager.getCookingTime() <= 0) {
                                onStop(view);
                            } else {
                                if (manager.getRunning())
                                {
                                    manager.reduceCookingTime();
                                    ((EditText)findViewById(R.id.textNumber)).setText(String.format("%02d",manager.getMinutesLeft())+":"+String.format("%02d",manager.getSecondsLeft()));
                                    handler.postDelayed(this, 1000);
                                }
                            }
                        }
                });
            }
        }

    public void onStop(final View view)
    {


    }

    @Override
    public void onCountDown(long timeLeft) {

    }

    @Override
    public void onEggTimerStopped() {
        manager.setRuning(false);
        findViewById(R.id.softBtn).setEnabled(true);
        findViewById(R.id.mediumBtn).setEnabled(true);
        findViewById(R.id.hardBtn).setEnabled(true);
        ((Button)findViewById(R.id.startBtn)).setText("Start");
        ((EditText)findViewById(R.id.textNumber)).setText("00:00");
    }
}