package com.example.eggtimer.Managers;

public class EggManager {
    long cookingTime;
    boolean running;

    public void setCookingTime(long value)
    {
        cookingTime = value;
    }
    public long getCookingTime()
    {
        return cookingTime;
    }
    public void reduceCookingTime()
    {
        cookingTime = cookingTime - 1000;
    }
    public long getMinutesLeft()
    {
        return (cookingTime/1000)/60;
    }
    public  long getSecondsLeft()
    {
        return (cookingTime/1000)%60;
    }

    public void setRuning(boolean value)
    {
        running = value;
    }
    public boolean getRunning()
    {
        return running;
    }
}
